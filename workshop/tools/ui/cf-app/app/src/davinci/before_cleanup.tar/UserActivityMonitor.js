define([], function () {

    var UserActivityMonitor = {
    };

    return UserActivityMonitor;
});
