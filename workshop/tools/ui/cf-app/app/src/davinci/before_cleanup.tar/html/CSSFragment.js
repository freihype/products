/**  
 * @class davinci.html.CSSFragment
   * @constructor 
   * @extends davinci.html.CSSFile
 */
define([
	"dojo/_base/declare",
	"davinci/html/CSSFile"
], function(declare, CSSFile) {

return CSSFile;
});
