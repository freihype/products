define({ root:
{
		//CloseVersionAction.js
		"areYouSureClose":"Are you sure you want to stop this review?",
		"closeSuccessful":"Stopped the review successfully!",
		
		//DeleteVersionAction.js
		"areYouSureDelete":"Are you sure you want to delete this review?",
		"deleteSuccessful":"Deleted the review successfully!",
		
		//OpenVersionAction.js
		"openSuccessful":"Started the review successfully!",
		
		//PublishAction.js
		"newReview":"New Review",
		"editReview":"Edit Review"
}
});
