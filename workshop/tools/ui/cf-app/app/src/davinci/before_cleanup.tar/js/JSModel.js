define([
	"dojo/_base/declare",
	"davinci/model/Model"
], function(declare, Model) {

if (!davinci.js) {
    davinci.js = {};
}

return declare("davinci.js.JSModel", Model, {
});
});
