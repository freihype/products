define(
    {
        revision: '',
        buildtime: '@buildtime@'
    });
