define([
	"davinci/lang/webContent",
	"./commands/CommandStack",
	"./ui.plugin",
	"./html/html.plugin",
	"./js/js.plugin",
	"./ve/ve.plugin"
	/*"./ve/themeEditor/themeEditor.plugin",
	"./review/review.plugin",*/
	//"./UserActivityMonitor"
], function(
	webContent,
	CommandStack,
	ui_plugin,
	html_plugin,
	js_plugin,
	ve_plugin
	/*themeEditor_plugin,
	review_plugin,*/
	//UserActivityMonitor
) {

// list of plugins to load
var plugins = [
	ui_plugin,
	html_plugin,
	/*js_plugin,*/
	ve_plugin
    /*themeEditor_plugin,
	review_plugin*/
];

var Runtime = {
	plugins: [],
	extensionPoints: [],
	subscriptions: [],
	currentSelection: [],
	commandStack: new CommandStack(),

	getUser: function() {
		return this._initializationInfo.userInfo;
	},

	getWorkbenchState: function() {
        if(!this._initializationInfo){

            return {
                "activeEditor": null,
                    "editors": [],
                    "nhfo": {
                    "project1": {
                        "device": "iphone",
                            "layout": "flow",
                            "themeSet": {
                            "name": "(none)",
                                "desktopTheme": "claro",
                                "mobileTheme": [
                                {
                                    "theme": "android",
                                    "device": "Android"
                                },
                                {
                                    "theme": "blackberry",
                                    "device": "BlackBerry"
                                },
                                {
                                    "theme": "ipad",
                                    "device": "iPad"
                                },
                                {
                                    "theme": "iphone",
                                    "device": "iPhone"
                                },
                                {
                                    "theme": "iphone",
                                    "device": "other"
                                }
                            ]
                        }
                    }
                },
                "project": "project1",
                    "id": "",
                    "Fields": []
            }

        }
		return this._initializationInfo.workbenchState;
	},

	/**
	 * Returns the site-specific data for "name"
	 * @param name {string}  Site-specific data index (e.g., "defaultThemeSet")
	 * @returns
	 */
	getSiteConfigData: function(name){
        if(name=='widgetPalette'){
            return {
                "_COMMENT1_":"Defines site-specific organization for widget palette",
                "name":"widgetPalette_dojo_default",
                "_COMMENT2_":"One entry for each section (==folder) in widget palette",
                "_COMMENT3_":"includes provides ordered list of widgets to appear in each section",
                "_COMMENT4_":"each entry in array causes a new item to appear in that section",
                "_COMMENT5_":"each entry in array can be either a string or an array",
                "_COMMENT6_":"if a string, can be either a string that begins with type:, which is a particular widget type",
                "_COMMENT7_":"otherwise the string holds a tag, which causes all widgets that match tag to share that item",
                "_COMMENT8_":"if an array, then it holds a list of strings, each of which can start with type: (widget type) or a tag",
                "defs":{
                    "$XBLOXSection":{
                        "id":"xblox",
                        "name": "xblox",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAKIAAFhYWtXV1v///0BAQP///wAAAAAAAAAAACH5BAEAAAQALAAAAAAQABAAAAMuSLo0w5CNIF6EM9grN2+Z82WCEGjcVJbopa5tlJ2nh4W2XH9LyCu+X/AHAPyOCQA7",
                        "subsections":[
                            "$XBLOXSection_Controls"
                        ]
                    },
                    "$XBLOXSection_Controls":{
                        "id":"Controls",
                        "name": "Controls",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQALMAAN7e4oyMjtXV1sDAwf///+Dg4MvLyzMzM////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAgALAAAAAAQABAAAAQ3EMlJq704a3RO2NIhBIexHYRgeFTndkQ8HmER33g60EcB/ECcYBd6wWSkDErFUs5Mms4HRK1SIwA7",
                        "includes":[
                            "RunScript",
                            "CSSState",
                            "StyleState",
                            "Script"
                        ]
                    },
                    "$ClipartSection_Arrows":{
                        "id":"Arrows",
                        "name": "Arrows",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQALMAAN7e4oyMjtXV1sDAwf///+Dg4MvLyzMzM////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAgALAAAAAAQABAAAAQ3EMlJq704a3RO2NIhBIexHYRgeFTndkQ8HmER33g60EcB/ECcYBd6wWSkDErFUs5Mms4HRK1SIwA7",
                        "includes":[
                            "ArrowDown",
                            "ArrowLeft",
                            "ArrowRight",
                            "ArrowUp"
                        ]
                    },
                    "$ClipartSection_Community":{
                        "id":"Community",
                        "name": "Community",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAMQAANXV1v///9HR0cXFxbm5uaKiooyMjHR0dGlpaVJSUkZGRkREREJCQkFBQT09PTo6OjMzM////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABEALAAAAAAQABAAAAVdIJEoZGmSiTgAbOuywwgEdAAY5WyTul0gAYFCB+DRWJCAqFArDo+QRcDRgBCNu1rgueMWG4FHw4u1Maa9bg8AdqSd6/a7zEZr4U35vRw4KA5aOwkrL4UxIieJCikhADs=",
                        "includes":[
                            "Facebook",
                            "Rss",
                            "Twitter"
                        ]
                    },
                    "$ClipartSection_Devices":{
                        "id":"Devices",
                        "name": "Devices",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYxIDY0LjE0MDk0OSwgMjAxMC8xMi8wNy0xMDo1NzowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDowMTgwMTE3NDA3MjA2ODExOTJCMEJDQTgxOTc0RDYxMiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo4NTQ0QUU2NjhCMzMxMUUyOTQ3N0ExRTg0NEJENzk4RiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo4NTQ0QUU2NThCMzMxMUUyOTQ3N0ExRTg0NEJENzk4RiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1LjEgTWFjaW50b3NoIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MDM4MDExNzQwNzIwNjgxMTkyQjBCQ0E4MTk3NEQ2MTIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MDE4MDExNzQwNzIwNjgxMTkyQjBCQ0E4MTk3NEQ2MTIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7l5plaAAAAIVBMVEX///8zMzP3+PnV1dZ+fn7ExMZ9fX4sKis1NTVZWVmgoKKPJ3BhAAAARElEQVR42mJgIAIwM8IBM1iAkRkO2KECTFBAiQCaoZjWsrKxcgIxEHKA+BysbGysQIKLi5OVEyjCiAYYWNAAYa8CBBgA3BQB3Pw68r4AAAAASUVORK5CYII=",
                        "includes":[
                            "Cellphone",
                            "Computer",
                            "Laptop",
                            "Server",
                            "Tablet"
                        ]
                    },
                    "$ClipartSection_DeviceSilhouettes":{
                        "id":"DeviceSilhouettes",
                        "name": "Device Silhouettes",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAKIAAGZmaNXV1v///0BAQP///wAAAAAAAAAAACH5BAEAAAQALAAAAAAQABAAAAM6SErT3iu+EF5UL4/LqPfbNQRCaVbcaJ6hRK4CKr6r7MJxu6iwvX8fHUbjSDUAFEBR5AAol0wNZzpNAAA7",
                        "includes":[
                            "Android_340x480",
                            "Android_480x800",
                            "AndroidTablet",
                            "Blackberry",
                            "iPad",
                            "iPhone"
                        ]
                    },
                    "$ClipartSection_Media":{
                        "id":"Media",
                        "name": "Media",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQALMAANXV1v////z8/Pr6+vn5+fj4+Ojo6MrKyre3t6urq4iIiHV1dUdHR0BAQDMzM////yH5BAEAAA8ALAAAAAAQABAAAARZ8MlJq6Ut36c5+E3VOGAGBEAWeif6DULghk0rB8jCLAhK2zjFoXBQIFKeW2BxSDQShwWypmQUGoZGgTEFMp1Q6U+JEBKN3RsBp+P5WJ+4HCRR2e+rjX5PiQAAOw==",
                        "includes":[
                            "Camera",
                            "Chat",
                            "GraphBar",
                            "GraphLine",
                            "GraphPie",
                            "Image",
                            "Map",
                            "Microphone",
                            "PlayControl",
                            "Record",
                            "StreetMap",
                            "Table",
                            "VideoCamera",
                            "VideoPlayer"
                        ]
                    },
                    "$ClipartSection_UserInterfaceControls":{
                        "id":"UserInterfaceControls",
                        "name": "User Interface Controls",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQALMAAFhYWtXV1qurrKGhooKCg/////X19TMzM////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAgALAAAAAAQABAAAARSEElwqrUyHxG678KRIVthDoNZhGNZBFVgsppQGId5GKtYF5dKr8X5eGiSoNKXJAie0CeBSbKprsgqMDj84XS8rAt2kHWT1gJKJS4aA1nSspKJAAA7",
                        "includes":[
                            "File",
                            "Folder",
                            "FormattingToolbox",
                            "HScrollBar",
                            "HSplit",
                            "ProgressBar",
                            "SpinInput",
                            "VScrollBar",
                            "VSplit",
                            "WaitingPending"
                        ]
                    },
                    "$ClipartSection_UserInterfaceIcons":{
                        "id":"UserInterfaceIcons",
                        "name": "User Interface Icons",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQANUAANXT1vj4+eLi49/f4Nra29nZ2tbW19XV1tTU1dDQ0c3NzpCQkf////7+/vX19fLy8vDw8O/v7+zs7OTk5OPj49nZ2dHR0c/Pz87Ozs3NzczMzKWlpaOjo6KioqGhoZ6enp2dnZycnJubm5mZmY+Pj4aGhoWFhYGBgX5+fnR0dHNzc2lpaWZmZllZWVdXV1VVVVNTU1FRUU5OTk1NTUxMTEJCQkBAQDY2NjMzMzIyMi8vLyoqKiYmJiMjI////wAAACH5BAEAAD4ALAAAAAAQABAAAAa8QJ/Qd0HRdD0dDXUZDj8ykqJgKGBIso/zs9IIIoFGICLQrLREWUZSmeHetookI2ueFgIGC6fSqHAzDAILJz4yFhF6LA8MD28MEQkyPjkEAQyYjS04LAwBBDk+PAYNmQ+bLYwNBjw+OJaZGzipmA4EOD4xB4mYIzgjmREHMT4mIhSZyZgUIiZELwgSvb+YEggvTT4eKQgDEB01HRATCCkcThwuIAcEAAQHIS/nTj4WJTA3OzcwJRb0/wB9BAEAOw==",
                        "includes":[
                            "Close",
                            "Copy",
                            "Delete",
                            "Edit",
                            "Error",
                            "Fatal",
                            "Help",
                            "Home",
                            "Info",
                            "Lock",
                            "Mail",
                            "Minus",
                            "Next",
                            "Paste",
                            "Plus",
                            "Previous",
                            "Print",
                            "Refresh",
                            "Save",
                            "Search",
                            "ShoppingCart",
                            "Trash",
                            "Warning"
                        ]
                    },
                    "$ClipartSection_Other":{
                        "id":"Other",
                        "name": "Other",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAJEAAHx8fDMzM////wAAACH5BAEAAAIALAAAAAAQABAAAAImlI9pAYoQDGxuHpvwZY8rrH1MWAWes53oRHZUK4Rkq8Gxp4roXgAAOw==",
                        "includes":[
                            "Browser",
                            "Person",
                            "ProfilePicture",
                            "X"
                        ]
                    },
                    "$ClipartSection":{
                        "id":"Clipart",
                        "name": "Clip Art",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAKIAAFhYWtXV1v///0BAQP///wAAAAAAAAAAACH5BAEAAAQALAAAAAAQABAAAAMuSLo0w5CNIF6EM9grN2+Z82WCEGjcVJbopa5tlJ2nh4W2XH9LyCu+X/AHAPyOCQA7",
                        "subsections":[
                            "$ClipartSection_Arrows",
                            "$ClipartSection_Community",
                            "$ClipartSection_Devices",
                            "$ClipartSection_DeviceSilhouettes",
                            "$ClipartSection_Media",
                            "$ClipartSection_UserInterfaceControls",
                            "$ClipartSection_UserInterfaceIcons",
                            "$ClipartSection_Other"
                        ]
                    },
                    "$DrawingToolsSection":{
                        "id":"DrawingTools",
                        "name": "Drawing Tools",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAKIAAL+/v5aWlmNjYzMzMxwcHBYWFv///wAAACH5BAEAAAYALAAAAAAQABAAAAMgaLrc/jBKFsBcg9g7iuaFZwlhaZrD1Ikqq35Xdc10PScAOw==",
                        "includes":[
                            "Text",
                            "Line",
                            "Arrow",
                            "Polyline",
                            "PolylineArrow",
                            "Circle",
                            "Rectangle",
                            "RoundedRectangle"
                        ]
                    },
                    "$ViewsSection":{
                        "id":"Views",
                        "name": "Views",
                        "_COMMENT1_":"Mobile-only view widgets, often representing a single screen of UI",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQANUAAC5KhTFOiPj6/jJRijRTjTRUjTdXkTdXkLrH3+Hp+OHp9zdakzZYkDdYkDlbkzlck97o+ODp+N/o9ztflj5km/L2/Pj6/T5mnD9mnT5lm0FqoENupENuo0Ruo0ZxpvL2+0l3rEl4rEh2qkl3q0l2qk6BtE1+sU+BtFCDtVCFt1CEtlSLvVOJulOHuVaOv7nW78/t+////////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAADIALAAAAAAQABAAAAaAQJlwSCwKXcikcilzxZ5QaApGVclWMUAWMFhgYiRYACGStaJoDKzyuchQr7hc3jAwGAeZCR1lKRIRLDIjWVtdXyUSEhAnMh58UCCKECEyGnOYHRsbHBwyFJBPGVQwFDIThQBcXjEOYggOMg+hMQUwFgIEsg+8vb0BwMBGw8TFQkEAOw==",
                        "includes":[
                            "ScrollableView",
                            "SwapView",
                            "View"
                        ]
                    },
                    "$HeadingSection":{
                        "id":"Heading, Section Labels",
                        "name": "Heading",
                        "_COMMENT1_":"Mobile-only Heading widgets, often titles at top of a screen",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAMQAAEh1qkd2q0d2qkh2q0h2qkt7r0t8r0+BtU6CtFGGuVGHuVSLvFaNv1WLvKzM6a3M6a3M6LfS7DJlklaOv4y64Iy635zD5J3E5KzN6azM6IK13Iy734273////////wAAACH5BAEAAB4ALAAAAAAQABAAAAVQoCeOZGmeaKqqU+u+LdN6U2Tf+D15S5ZJwIzjgXFkIJmGJ2GRtCSbTWc6vSg8hw0HCN1UKFotwlPQmM/os8FDIADcgYGAIJgD3qu8fs/nhwAAOw==",
                        "includes":[
                            "Heading",
                            "ToolBarButton"
                        ]
                    },
                    "$ContainersSection_Dojo":{
                        "id":"ContainersSection_Dojo",
                        "name": "Dojo",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAg9JREFUeNp8ks1rE0EYxn9bE/xqikI0lITiQW+VImoONmCQtoonUbAglFDEUtlLxdo/wUNRD0Iw1kOIEmj6D9ir2FRQi4j0lILQJoimRfJB9mNmOx42iWsT+8Iw7DwPv32feUdTSuGtyeQKaT3GZHJlGEgA40AOyKT1WL6lt0rbC2hC9IFg7/a1c5HAib5Dc+WqOb/8pVjb3K4H03os6fVqXToYHgj2RiYun34KhD1S6c27jYeb2/ViWo/lW4c9dFYiPtgfMIQTNoRDw3YwbIeGcMLxwf5AM1a7fF0A436fL15pSNAUGqCUhqYp/P4Dc0AImNoPkNvaqX8MHDn4SkOBiwA0Kg1rHoh6zd0iZD4VyrWaKUpVQ1I1bSqGpGKI0udCuQZk/gu4+XhZpfXY2amRM88vnjq2vlMz7xn2biF41L8+FAl8f5a4cFw4u/mrj3KqK0BYNkDqzv3UyR6N32uFn9H334qhtY1fhyf0lzEgVd76oQDaEKVUe43NLirP97Rnn97rG5tdRCnldrCw9EFd0TNKNEwARmayCkg1tRdAavRBVo3OZAFwpMQR8m+E12+/YjcMzW4CpBsFF7AKgG1aCNM9l4bd9vjc7FZ73gDCtDpGIw27Oc5/9R6AuzeiSFsqRwjX7DH0hYK0fiKbHSSuDyEtq/MSu63zt56o/fRuL5HWxS4srTJ1+xL71Z8BAL+kU+9a36VRAAAAAElFTkSuQmCC",
                        "includes":[
                            ["AccordionContainer","Accordion"],
                            "BorderContainer",
                            "Container",
                            "ContentPane",
                            "FixedSplitter",
                            "Form",
                            "GridLayout",
                            "MenuBar",
                            "Pane",
                            "RoundRect",
                            "ScrollablePane",
                            "TabContainer",
                            "TitlePane",
                            "ToolBar"
                        ]
                    },
                    "$ContainersSection_HTML":{
                        "id":"ContainersSection_HTML",
                        "name": "HTML",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjVFNUZFNTNBNTk0QjExRTBBNkY0ODEzNDdCMzkxNTdDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjVFNUZFNTNCNTk0QjExRTBBNkY0ODEzNDdCMzkxNTdDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NUU1RkU1Mzg1OTRCMTFFMEE2RjQ4MTM0N0IzOTE1N0MiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NUU1RkU1Mzk1OTRCMTFFMEE2RjQ4MTM0N0IzOTE1N0MiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5wB++kAAABAklEQVR42qRToQ7CMBC9LYhK5Bz9AyaHYhIHEomcYxI5iRwOOYkcDgkKWxxyuElwnSq5hpJ2tAvJXnK5vuvd60u7eUII6IOBTo67SafafH31foroQEWZR8IFVibis2/M+G3BV9NYTydkCJSGPy59WzOKtMMlYghUTwLsXsMsLQA4yIwc10GUyaBxLvusAuGigM3+BHFIJceMnFW182K/ApfbQ6jhdBnjoTLrIljjLgF9WIcu0ulgm8zgzCrID2ejATnWcV+htt3BdDzydBHOzWEaBLLGucMB4lQkXycIffivTxmBzYdsJdcqd8GHnmg5ILDfLrXHIpaHIwbz+v7ObwEGADGQtFOesBZAAAAAAElFTkSuQmCC",
                        "includes":[
                            "<a>",
                            "<div>",
                            "<span>",
                            "<table>",
                            "<style>"
                        ]
                    },
                    "$ContainersSection":{
                        "id":"Containers",
                        "name": "Containers",
                        "_COMMENT1_":"Desktop and mobile containers",
                        "_COMMENT2_":"Note that default desktop preset only include desktop widgets",
                        "_COMMENT3_":"and mobile preset only include mobile widgets",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAARJJREFUeNqkUzFuhEAMNFHqHAUEiU9Q0PKS3BNo6O9aJMQDqHkM4iG05CJdGgpgfXhvvVqyECHdSNaO7PWMsRYHEaGua+z7Hgi+7wPzLZh14kACZVniPM8yTM4xTZMOqpv8nZSEENqB+e/9DmIRJ6A6Xddd3aW8FFhcrFE/TifdaEHllymeAkQYQRBAURS7OwjDEFh2U6DrOrheLrDjDXmea64FxnHU4w7DIJt/bt+AAtVenqf36cs6/DcBc2piAUSxriszMn6DF2FNcAR45BM8z9tc5N+7lkAURZBl2a57HMe2gHxIajFt20JVVasHY06Spimcv87AfS8v0eG/sWkamUiSBJhvwawTd3bf+0E8BBgAL2nsdz3dOk4AAAAASUVORK5CYII=",
                        "subsections":[
                            "$ContainersSection_Dojo",
                            "$ContainersSection_HTML"
                        ]
                    },
                    "$ListsSection":{
                        "id":"Lists",
                        "name": "Lists",
                        "_COMMENT1_":"Mobile-only List widgets",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAMQAADlck9jf6ra/zGiKukNvpERvo/P3/Ex7r0x9sUx8r1KHuVKHuFaOv3io0bnW78jg8////////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABEALAAAAAAQABAAAAVWYCSOZGmeptEwbNs2hmgwgWHfd8DETQD9wKAh0IgsDBBEcGlQRBLIpfTwdFiv2CsVKp1GCkhlF2IgRAaC8c8gGEQeAAFuLgA8RI8BYM/nD+4ogYKDgiEAOw==",
                        "includes":[
                            "RoundRectCategory",
                            "RoundRectList",
                            "RoundRectDataList",
                            "EdgeToEdgeCategory",
                            "EdgeToEdgeList",
                            "EdgeToEdgeDataList",
                            "ListItem"
                        ]
                    },
                    "$ControlsSection_Buttons":{
                        "id":"Buttons",
                        "name": "Buttons",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQANUAAC5KhTFPijZXkDZYkDxhmTtimUJsouHr9/D1+0h2q0l3q7XQ7bbQ7bbQ7MLX79vo9k6AtE6Bs6TH6bbR7NLj9FKJu1OJulaNv5C95aTH6KTI6LXR7L/Z8Mje8laOv36z4X604JC95LnW77/a8Nzr9////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACUALAAAAAAQABAAAAZiwJJwSCwaj8hk0cP0XJpQj9ByqFqvVUSlFDk4vuCw4wApKR6MxmLCbm8mj0TJQNFI7nh8hmIoFTohGIKDgyEdBCUDHCAfHyCPkI0jAiUBIpeYmZckAUIAn6ChoEqkpaanRUEAOw==",
                        "includes":[
                            ["Button","<button>"],
                            "ComboButton",
                            "DropDownButton",
                            "ToggleButton"
                        ]
                    },
                    "$ControlsSection_CheckboxesRadios":{
                        "id":"CheckboxesRadios",
                        "name": "Checkboxes, RadioButtons, Switch",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAP9JREFUeNpi/P//P8PGnQf/M5AJWGAMf3d7kjUDLUYYAAITd94kWnO+uzqqC2DAQkGAgYEDwpbg4ICLv/jxA8IAUicefMD0Agw8+ABRCNL7geEHXBwkHG4uD2avuPAAtwEQS4Cqf3DAtX8A2p5urw6Xv3DjBZzNhMuPP6Da0TUHdu5ksNCQwG0ASEO8uToYv/iAqtmxcSODAjCMBAQ48BuAHtIwzQZAmzUkBIBhzIHfCyBnIgNkzQJIMYPVAJACkDNBmghpxhoLEkD/CXBIgBUXzjzI4GCgAHE2B4GkDE8HLxDpQACq8cWHH4TzAnqgkZyZQBmDHMAIys6UAIAAAwBz81X4fS5oMgAAAABJRU5ErkJggg==",
                        "includes":[
                            "CheckBox",
                            "RadioButton",
                            "Switch",
                            "TriStateCheckBox"
                        ]
                    },
                    "$ControlsSection_IconContainer":{
                        "id":"IconContainer",
                        "name": "IconContainer",
                        "_COMMENT1_":"Mobile-only",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAMQAACVLiiVLiDlck/P2+zxhlzpppj9mnDh3xUJtokdzp3ak21ON0FCDvEp6rU6As1SKvFaOv////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABEALAAAAAAQABAAAAVoYBRBZGmWIjSsbMtC0TMo9FzTyvBEzrD8PuBvMXBEGoODMrlUHgaNSMJFXSUiiAGgwNByvV1ExFClGiIEWw6nHhAigiBxKB8I4MynM2/Hl1t3cQFfg12FfXF/LHdwAo6PkI4ik5SVkyEAOw==",
                        "includes":[
                            "IconContainer",
                            "IconItem",
                            "IconMenu",
                            "IconMenuItem"
                        ]
                    },
                    "$ControlsSection_Pickers":{
                        "id":"Pickers",
                        "name": "Pickers",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQANUAAKFMUiI5ZjxsuTlckz1jmj1jmVyL0T1kmUNvpERvpERuo0Rvo16W2jx7wEeO4Et7r0x7r26ayUt8r0x8rqrS+lGHuVKHuZXN/1aOv6u7yJypq+38++v6+aiysJ6uqWpNK5RcON6CV+esnbq2tf/X0t26tuxmXtaJhL+Zmf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACkALAAAAAAQABAAAAZswJRwSCwSA8YhUrlMBpbPpjEqfCarUmlRezVivmBMKgweXyIMgUGMOafXKcvog2o4LKnKvH5PTUIgIh0UECkPgIIUEikLGQAnGxoJKQiOkBoKKQUcJSYkHgUpBJyeHgcpA6mqA6irqV2wsUJBADs=",
                        "includes":[
                            "Carousel",
                            "CarouselItem",
                            "DataCarousel",
                            "DatePicker",
                            "SpinWheel",
                            "SpinWheelSlot",
                            "SpinWheelDatePicker",
                            "SpinWheelTimePicker",
                            "TimePicker",
                            "ValuePicker",
                            "ValuePickerSlot",
                            "ValuePickerDatePicker",
                            "ValuePickerTimePicker"
                        ]
                    },
                    "$ControlsSection_Select":{
                        "id":"Select",
                        "name": "Select",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAVJJREFUeNpi/P//PwMlgAVEhPcf+E+RAb++fWeoz3QlqLhxxh6G+gwXBH/6bgYmEOPHp69gAVGGvwxijH8ZhP/9AbNhWJwRgn9+/AxWl5TYy/D61hOgvi8QF3z/8Akswc/JjGLjfwZGMM0IZIHY3z5ADDi4ogQs+23+XgZGUCBaRE4EByUjRBeUATOEASoANe4/0DhGqOh/aBjIm+kzfn37/n+IkxZJAbhm3zWIAX9//WHg4OVlMDBQZhD6+5doA7aceQQx4M/PnwywePRN6IVEDzsrAysnJwMHDxcDGxCDaFZODoZJqfZwA/78+AWLxh9wf+9cWkK0C359/wEx4DeQAXOBe3QPXhfAwKwsJ3D6gSckmAGHV5cT7YLf36AuADkFBmxDO4lyweJCZ7DLIbEADIz/0DA4vaGSeBcA9YETkpF/JyLNMGBJTXgAI6XZGSDAAJsyjhMJL+H/AAAAAElFTkSuQmCC",
                        "includes":[
                            "ComboBox",
                            "DropDownButton",
                            ["DropDownSelect","<select>"],
                            "FilteringSelect",
                            "MultiSelect",
                            "Select",
                            "<select>"
                        ]
                    },
                    "$ControlsSection_SlidersSpinners":{
                        "id":"SlidersSpinners",
                        "name": "Sliders, Spinners",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQANUAAM7W5DdYkDteljpfloOcwUBonkBonUFonkdzqEdzp3CUv+Tt+EZzp9Xk9Njm9dvo9kx+sU1+sZ/E6K3M68re8tDh89fm9VKHuYO14pC95ZG95Z/F6KzM663N68ne8tDi89Xl9FaOv4O24pG+5aDJ6tXj76nR7v///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACcALAAAAAAQABAAAAZZwJNwSCwaj8ikcjkMOZ/J0KJBbSxCyMtnwulMPpdiKcSIUDZoiSfCCJWEERIB8RhpMppHglCBCA0mJgoHFiIYDgYKgQVCAAGPAQIgIAOQAQBIj0ybnJ2eJ0EAOw==",
                        "includes":[
                            "HorizontalSlider",
                            "NumberSpinner",
                            "Slider",
                            "TimeSpinner",
                            "VerticalSlider"
                        ]
                    },
                    "$ControlsSection_TextBox":{
                        "id":"TextBox",
                        "name": "TextBox",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAM1JREFUeNpi/P//PwMlgImBQkCxASzIHIvIif/lzfQZHp66yHBieT4jUSaAwgAZm0dM+I8uhg+DXRDefwAckqGWCmBD15x48H/18QcELV9Z6MAINuDPz98MtWmODBKcTAw9QL6NvhyDipoMXs0ts/chwuD39+9gDjfDfzgtyvAXe6hDQ+bXtx8IA94+eArmsLMywml+Bmbc4cbAyPD24VOEAX9//WLIyJ7KkBJiARZctPE0w5w1JxjoEgtM2NIBiCY2ITEO/bxAsQEAAQYAGVGarS2fPq4AAAAASUVORK5CYII=",
                        "includes":[
                            ["TextBox","<input>"],
                            "ComboBox",
                            "CurrencyTextBox",
                            "DateTextBox",
                            "DateTimeTextBox",
                            "NumberTextBox",
                            "SimpleTextarea",
                            ["Textarea","TextArea","ExpandingTextArea"],
                            "ValidationTextBox",
                            "TimeTextBox"
                        ]
                    },
                    "$ControlsSection_Toolbars":{
                        "id":"Toolbars",
                        "name": "Toolbars, ButtonBars",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAOtJREFUeNpi/P//PwMlgAVEhPcf+E+RAX9+/mKoTXMiWXPTzH0MTCDGzy9f4YIxmZOIokHg19dvDIygMHAtWPq/vjQYLPgfCHecf8ngaSTOsP0cHtpQgqGxey3ECyCT3n/9CdINNsJCTZDh/ZdfcNoSRH9G8C1UBYDqfyBcYJowg7JAlJCVYGgu9CFZc+2ErRAD/v39BxZQ4STNgL9//kBi4R+QQQ749+cvzIC/ZBoAdcFfSl3w69t3sgwA6QMb8PsfeVH4599/aCwA00Jy2QIG5n+YJv1lYgKLw+h/QBqUaCBizJCERAkACDAAug6MMt3XrLUAAAAASUVORK5CYII=",
                        "includes":[
                            "TabBar",
                            "TabBarButton",
                            "Toolbar"
                        ]
                    },
                    "$ControlsSection_Other":{
                        "id":"Other",
                        "name": "Other",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQANUAADlckzthmDxhl0BonkBonUVwpUp6rU+BtU+CtFOJu1OKu1aOv/b8//n9/8/t++/6//L7/+v5/+76//X8//j9/+v6/+77/+/7//L8//b9//X9//n+//j+///ovfvcsvTKofTJofbKo/TJo/TKo+20kOegfeeffuegfuWfff///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACkALAAAAAAQABAAAAZfwJRwSCwaj8ikUrloOp/QVIJErZIc2Kwiheh4v9dKpEI+pAyetPp6eVgsEkOq8AGNRKAQyoGB9DEFKQRWVHsTGgwaGQMpAiclJiYoJ3sNDRwbFAEpAJ2en6BLoqOkpEEAOw==",
                        "includes":[
                            "ProgressIndicator",
                            "Rating",
                            "SearchBox"
                        ]
                    },
                    "$ControlsSection":{
                        "id":"Controls",
                        "name": "Controls",
                        "_COMMENT1_":"each section can either have an array of subsections or an array of includes",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjgyQUEwNTdCNTk1MTExRTBCODIzOTk0QzIzMzdBNkNGIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjgyQUEwNTdDNTk1MTExRTBCODIzOTk0QzIzMzdBNkNGIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ODJBQTA1Nzk1OTUxMTFFMEI4MjM5OTRDMjMzN0E2Q0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6ODJBQTA1N0E1OTUxMTFFMEI4MjM5OTRDMjMzN0E2Q0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7ZOYfnAAABBUlEQVR42pRSKxCDMAztdgjkJBKJnKxETk5WIpGTlcjKykpk5SSyEolETk4iI9eRrpSud7tF5NK8vHweHHoz38cHSdmVlhFkM5lN9W2dJDTKRJDNZBgxrum5oOdynB7j9NSC+aJhXjC4VCfrHQErLO0dsN2cBUDwjosOn0fyy2y19+8JsMDWjMA3QSkRPjMCW9GJ5CFWFzllu+qW1RmsXfHoW0OlNv7oYX52XRsS+rtVCbajrdGq9EeH2/rMQfZGaRPNxYwPdivpYRo1D8W+tAo3kVJ/Q+478Bt32UH5PSAFHWFVqVllRr/ploLc0VWRCyl2nT9BBDlZ8T8hKUYE/a3SS4ABAP4rm5Sxt9t9AAAAAElFTkSuQmCC",
                        "subsections":[
                            "$ControlsSection_Buttons",
                            "$ControlsSection_CheckboxesRadios",
                            "$ControlsSection_IconContainer",
                            "$ControlsSection_Pickers",
                            "$ControlsSection_Select",
                            "$ControlsSection_SlidersSpinners",
                            "$ControlsSection_TextBox",
                            "$ControlsSection_Toolbars",
                            "$ControlsSection_Other"
                        ]
                    },
                    "$HTMLSection_Common":{
                        "id":"Common",
                        "name": "Common",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAALNJREFUeNpi/P//P4NUxvb/DGQCFhjj2QxPkjUDLWZgYqAQgA34//8fmNO74TIcwwCMjU2MAagPbADTv79wyeIAXTBG1oALMAL1gcOA8f9vgoqRDQWxIfr+QF3w9w95/v/7C+qCf78x/AezBa8XgC5gAKUDhZh5/8kBIH3QQPxNlhdALqdOOmD8+5vMQIS6gPH/X/K8ANQHDQMyoxEYC9CE9I9BI6SHdBeA9f7/T1EgAgQYAMdnhUefY5wVAAAAAElFTkSuQmCC",
                        "includes":[
                            "<a>",
                            "<div>",
                            "<label>",
                            "<span>",
                            "<style>"
                        ]
                    },
                    "$HTMLSection_Forms":{
                        "id":"Forms",
                        "name": "Forms",
                        "iconBase64": "data:image/png;base64,R0lGODlhEAAQAOYAAPT2/PH0+/n6/Iaavoyfwt/o+OLq+Onv+pOmxt/o9+bt+N7k7unv+e3y+sbT59/p+OLr+PD0+t/p9/D1+/f5+5DDvKfMxgBZSqfNxgJbSqjNxqjMxQZeSqjNxQZfSgpiSgphSg9mSrXSyRNrShNqSb3Vy5zKtp3Ktr3Wy5zKtZ3KtR1zSaDMtSJ3ScTYzSZ6SSZ7SSl+SSl9SSp+SSp9SaTNtCyASXt0T392ToV5TIx8SpOASKOIQ5yEReDIj97WwbSQPbCOPquLQNSyaNSyadq9fObav9Wyaf///////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEkALAAAAAAQABAAAAeQgEmCg4SFhoeIhECLi4g2NklASEgCRECHNi40RpMURUdBgjAxMzIzKCUvSAgAPkVDQkktIrS1Ii0RExERATxJKx0bGhYdGMIrDgQDDT1JJBXQ0dAjDAwHDDtJISYnKSom3CEOCMoKOkkgHOoeLCwfCxAG8hA5hRk1HD8J+w8SBTiFLlxIcqOgwYKJEipcaCgQADs=",
                        "includes":[
                            "<button>",
                            "<fieldset>",
                            "<form>",
                            "<input>",
                            "<select>",
                            "<textarea>"
                        ]
                    },
                    "$HTMLSection_Headers":{
                        "id":"Headers",
                        "name": "Headers",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAIpJREFUeNpi/P//PwMlgImBQkCxASwggtW3bzeQcgFiVx5NrT0gsS/Xr2GIwQBQbiaQSgPJkewCoOZyqGaEC4jUqASkQK5SIjcMlKC4Aoj34HLBbqBNuAy4B8TKwPC4B1TjgsuAs0D8Hso2BmJBmARIIzHRWAFUCAp1V6hhQyAhUWwA49DPTAABBgDGmykkJRol4AAAAABJRU5ErkJggg==",
                        "includes":[
                            "<h1>",
                            "<h2>",
                            "<h3>"
                        ]
                    },
                    "$HTMLSection_ImagesMediaIframes":{
                        "id":"ImagesMediaIframes",
                        "name": "Images, Media, Iframes",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQANUAAOnn6f////7+/v39/fz8/Pr6+vn5+ff39/X19fT09PLy8vHx8e/v7+fn59/f397e3tvb29bW1sfHx8LCwsHBwby8vLq6urm5uba2trS0tLKysq2traKioqCgoJycnJSUlJKSkpGRkYuLi4qKiomJiYSEhHh4eHV1dXR0dGlpaWhoaFxcXP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACwALAAAAAAQABAAAAaPQBYLNAQZjcJk0mgJOBeEkXI5jEwmHMJCNC1uIBNKxzTwEJWhocPxkAQIBgY3+QFpAJTJxnRarU5KRCANVxkcFygsJIEfGAx5eQoZSFQgCQkIlwREaUsgFwdXYQIXlEJpIAWiFAEfQ4EgFQFheQEWpq8gTrsBnLBNkBO2dWhDsxTIrSydQioqKc7P0iolQkEAOw==",
                        "includes":[
                            "<audio>",
                            "<embed>",
                            "<img>",
                            "<iframe>",
                            "<video>"
                        ]
                    },
                    "$HTMLSection_ParagraphsFormatting":{
                        "id":"ParagraphsFormatting",
                        "name": "Paragraphs, Breaks, Rules",
                        "iconBase64": "data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAEZ0FNQQAAsY58+1GTAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAHGSURBVHjaZFLJbhNREKx+b2Yc7xs2EEVZlEgR4oKEOHLiH/gEfokP4EM4I0UcEApCkYAoIDlWGC9je2ymFw4zA9jUqaWu6up6r+nT1XWn1QDAnMEU2/BB5HxoxjAAmM4XQb/TGtzrcBprfOXC2l8ugVnHox+9w6eN7kGhdy4QVQCrZB7WjqOykYMZy9E0vXg9fPKqOzgCIKou76kZs6w2WbL6laRZkmarDXNmlfqg2xvefngzGX/NbYNimkFU3328niTrMKrA+Ua18vzRg73W4ab20iq38eimOzwBSoGamWLQaVSj0PuAnAO591/uWG2/1z46aU++X+bMPw7GgpvxLJ4tgzByPiDnyXkxNKt7+83Iygd0JR/MCjgiclTAERHBDBmriG05qGrG+uLZuUk5oIQYVou5qm4JzCCii1QlYxBgAIEAGMg7EdUdBzMTsbcXn+N5EoYR+ZCcd96z4Pygd9orvuvfDMZS7GEglBUoNzfV3Qym8I/PjjebdZ4WRCAyo2atwpLuCgDcfbvsCwfCO6GXoFUyrQfrQuCdA/Dw+CyKIsDyRXZg9xvt/rA4vp/TuagSka8PczL9JyDQbC26jKezxe8BAJ6U+/2r7MIJAAAAAElFTkSuQmCC",
                        "includes":[
                            "<b>",
                            "<br>",
                            "<em>",
                            "<hr>",
                            "<i>",
                            "<p>",
                            "<s>",
                            "<strong>",
                            "<u>"
                        ]
                    },
                    "$HTMLSection_Tables":{
                        "id":"Tables",
                        "name": "Tables",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAXhJREFUeNrEUz1LA0EQnTvzO/wPYsBOrQW109ImpLPIL9DWKqQQRESEFGKjYmGwEyQggUTBRn+BIhFFTXK53Z1xZi53ulcpKdxjmXnD7Lv39iMgIhhnhDDmKKTJavXyz1KOKvNBRkCIsFWe09wxFbI1iTEy5ppB0shB69v1K18BOdTYvHvUZm1k0oi7rUwhIIkAs8VJQESfwMQxVGoXv5Le7jxAwF/yZ2aVubRxRjKYmWJrqXZyQ/3I0HtvSG8fA8Xd1z49v/ToqftJi5va/30KJhqOyGQ/WL6xCcZkCkakrMcOopyFKGKvCGLNslFrDMTGqX8hECz7AKN7YwZDnwC5uXp47XndPW17uN64zXK0zidwzsH6yozKNKxg57gFpeUi11EtHZx3YG1hKiNoNO9zx8iMcjRigWQFYuJfVAMp/jmcRf8qG90sUAWoEWUZpG8FcwRICQ7ShunSniYToiIMIb3XguXELdcKnEtM6639chD8+2v8EmAA9/wqJKl9P7kAAAAASUVORK5CYII=",
                        "includes":[
                            "<table>"
                        ]
                    },
                    "$HTMLSection":{
                        "id":"HTML",
                        "name": "HTML",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjVFNUZFNTNBNTk0QjExRTBBNkY0ODEzNDdCMzkxNTdDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjVFNUZFNTNCNTk0QjExRTBBNkY0ODEzNDdCMzkxNTdDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NUU1RkU1Mzg1OTRCMTFFMEE2RjQ4MTM0N0IzOTE1N0MiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NUU1RkU1Mzk1OTRCMTFFMEE2RjQ4MTM0N0IzOTE1N0MiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5wB++kAAABAklEQVR42qRToQ7CMBC9LYhK5Bz9AyaHYhIHEomcYxI5iRwOOYkcDgkKWxxyuElwnSq5hpJ2tAvJXnK5vuvd60u7eUII6IOBTo67SafafH31foroQEWZR8IFVibis2/M+G3BV9NYTydkCJSGPy59WzOKtMMlYghUTwLsXsMsLQA4yIwc10GUyaBxLvusAuGigM3+BHFIJceMnFW182K/ApfbQ6jhdBnjoTLrIljjLgF9WIcu0ulgm8zgzCrID2ejATnWcV+htt3BdDzydBHOzWEaBLLGucMB4lQkXycIffivTxmBzYdsJdcqd8GHnmg5ILDfLrXHIpaHIwbz+v7ObwEGADGQtFOesBZAAAAAAElFTkSuQmCC",
                        "subsections":[
                            "$HTMLSection_Common",
                            "$HTMLSection_Forms",
                            "$HTMLSection_Headers",
                            "$HTMLSection_ImagesMediaIframes",
                            "$HTMLSection_ParagraphsFormatting",
                            "$HTMLSection_Tables"
                        ]
                    },
                    "$AppOtherSection":{
                        "id":"Other",
                        "name": "Other",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAcFJREFUeNqcUj1IQlEUPjfc+llqCEKwpaCgrJZqKOhnqiChsbQhF+f2moqgpaH2rDEqiiCwBB2sRbJArYa0hohSCLTQ93rvds95710VHaIDx/P5ne+ce869j3HOAW039MCPr9PwV5sddIBntJPZLAKLV+eHCDMpY2UlnP5bvyv7V9gA6qx04bMAmbwKmZwiXIWPvAI9bY0iFikSh7m8QhrUo9nKx8IknsTFGYyXcwDvohHDgbgxhWUVDbJfijE23osIO+Fnmnw79CKKzTJswEot5Aq+uV6Ix+6FJ8HewCESjJIjTtwmKWev5xAXOCEw6o2G4jR039Y5z+WK5H/FWCdX4HppLEykMtkqrJu4vaWZML2T9R2cRtP8LJygS5wa6QYDg8BdNbChmRlwMLmCd/NUjmfhu9Qr4enlALl384Q4S4N18hJ1XYeaWNMk1rRqTcUKR4Ebwq7JPiAsnss10Q9HFyY/YfKmpmKFpY0T/v2tkrvXDig+vWX54vohRXTUYMScR2gqXqGoFEqvYI7X2tQkxv6hSBq1IHHVCoHII/cHY/QJL4w7wX8ZI94t8J7gUYYYNcSPOWFyuIPJBv+1XwEGAJJgewSkj0bcAAAAAElFTkSuQmCC",
                        "includes":[
                            "Calendar",
                            "ColorPalette",
                            "GridX",
                            "RichText",
                            "StickyNote",
                            "Tree",
                            "$$AllOthers$$"
                        ]
                    },
                    "$SketchOtherSection":{
                        "id":"Other",
                        "name": "Other",
                        "iconBase64": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAcFJREFUeNqcUj1IQlEUPjfc+llqCEKwpaCgrJZqKOhnqiChsbQhF+f2moqgpaH2rDEqiiCwBB2sRbJArYa0hohSCLTQ93rvds95710VHaIDx/P5ne+ce869j3HOAW039MCPr9PwV5sddIBntJPZLAKLV+eHCDMpY2UlnP5bvyv7V9gA6qx04bMAmbwKmZwiXIWPvAI9bY0iFikSh7m8QhrUo9nKx8IknsTFGYyXcwDvohHDgbgxhWUVDbJfijE23osIO+Fnmnw79CKKzTJswEot5Aq+uV6Ix+6FJ8HewCESjJIjTtwmKWev5xAXOCEw6o2G4jR039Y5z+WK5H/FWCdX4HppLEykMtkqrJu4vaWZML2T9R2cRtP8LJygS5wa6QYDg8BdNbChmRlwMLmCd/NUjmfhu9Qr4enlALl384Q4S4N18hJ1XYeaWNMk1rRqTcUKR4Ebwq7JPiAsnss10Q9HFyY/YfKmpmKFpY0T/v2tkrvXDig+vWX54vohRXTUYMScR2gqXqGoFEqvYI7X2tQkxv6hSBq1IHHVCoHII/cHY/QJL4w7wX8ZI94t8J7gUYYYNcSPOWFyuIPJBv+1XwEGAJJgewSkj0bcAAAAAElFTkSuQmCC",
                        "includes":[
                            "Calendar",
                            "ColorPalette",
                            "GridX",
                            "RichText",
                            "StickyNote",
                            "Tree",
                            "$$AllOthers$$"
                        ]
                    },
                    "$mobileSections":[
                        "$ViewsSection",
                        "$HeadingSection",
                        "$ListsSection",
                        "$ControlsSection",
                        "$ContainersSection",
                        "$HTMLSection",
                        "$ClipartSection",
                        "$XBLOXSection",
                        "$DrawingToolsSection",
                        "$AppOtherSection",
                        "$StatesSection"
                    ],
                    "$desktopSections":[
                        "$ContainersSection",
                        "$ControlsSection",
                        "$ViewsSection",
                        "$HeadingSection",
                        "$ListsSection",
                        "$HTMLSection",
                        "$ClipartSection",

                        "$XBLOXSection",
                        "$DrawingToolsSection",
                        "$AppOtherSection",
                        "$StatesSection"
                    ],
                    "$sketchSections":[
                        "$DrawingToolsSection",
                        "$ClipartSection",

                        "$ControlsSection",
                        "$ContainersSection",
                        "$HTMLSection",
                        "$HeadingSection",
                        "$ListsSection",
                        "$SketchOtherSection"
                    ],
                    "$sketchExcludes": [
                        "dojox.mobile.ScrollableView",
                        "dojox.mobile.SwapView",
                        "dojox.mobile.View"
                    ],
                    "$ALLMOBILE_Sections":[
                        "$ViewsSection",
                        "$HeadingSection",
                        "$ListsSection",
                        "$ControlsSection",
                        "$ContainersSection",
                        "$HTMLSection",
                        "$ClipartSection",
                        "$XBLOXSection",
                        "$DrawingToolsSection",
                        "$AppOtherSection",
                        "$StatesSection"
                    ],
                    "$ALLDESKTOP_Sections":[
                        "$ContainersSection",
                        "$ControlsSection",
                        "$ViewsSection",
                        "$HeadingSection",
                        "$ListsSection",
                        "$HTMLSection",
                        "$ClipartSection",
                        "$XBLOXSection",
                        "$DrawingToolsSection",
                        "$AppOtherSection",
                        "$StatesSection"
                    ],
                    "$deliteSections":[
                        "$HTMLSection",
                        "$XBLOXSection",
                        "$DELITESection",
                        "$StatesSection"
                        //"$ClipartSection",
                        //"$DrawingToolsSection"
                    ],
                    "$ALLDELITE_Sections":[
                        "$HTMLSection",
                        "$XBLOXSection",
                        "$DELITESection"
                    ],
                    "$DELITESection_Controls":{
                        "id":"delite",
                        "name": "Controls",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQALMAAN7e4oyMjtXV1sDAwf///+Dg4MvLyzMzM////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAgALAAAAAAQABAAAAQ3EMlJq704a3RO2NIhBIexHYRgeFTndkQ8HmER33g60EcB/ECcYBd6wWSkDErFUs5Mms4HRK1SIwA7",
                        "includes":[
                            "Button",
                            "Slider",
                            "Combobox",
                            "Select",
                            "Checkbox",
                            "RadioButton",
                            "Switch",
                            "ToggleButton",
                            "MediaPlayer"

                        ]
                    },
                    "$DELITESection_Containers":{
                        "id":"delite",
                        "name": "Containers",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQALMAAN7e4oyMjtXV1sDAwf///+Dg4MvLyzMzM////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAgALAAAAAAQABAAAAQ3EMlJq704a3RO2NIhBIexHYRgeFTndkQ8HmER33g60EcB/ECcYBd6wWSkDErFUs5Mms4HRK1SIwA7",
                        "includes":[
                            "ViewStack",
                            "Panel",
                            "TabBar",
                            "Accordion"
                        ]
                    },
                    "$DELITESection_States":{
                        "id":"delite",
                        "name": "States",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQALMAAN7e4oyMjtXV1sDAwf///+Dg4MvLyzMzM////wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAgALAAAAAAQABAAAAQ3EMlJq704a3RO2NIhBIexHYRgeFTndkQ8HmER33g60EcB/ECcYBd6wWSkDErFUs5Mms4HRK1SIwA7",
                        "includes":[
                            "CSSState"
                        ]
                    },
                    "$DELITESection":{
                        "id":"delite",
                        "name": "Deliteful",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAKIAAFhYWtXV1v///0BAQP///wAAAAAAAAAAACH5BAEAAAQALAAAAAAQABAAAAMuSLo0w5CNIF6EM9grN2+Z82WCEGjcVJbopa5tlJ2nh4W2XH9LyCu+X/AHAPyOCQA7",
                        "subsections":[
                            "$DELITESection_Controls",
                            "$DELITESection_Containers"
                            //"$DELITESection_States"
                        ],
                        "includes":[]
                    },
                    "$StatesSection":{
                        "id":"States",
                        "name": "States",
                        "iconBase64": "data:image/gif;base64,R0lGODlhEAAQAKIAAL+/v5aWlmNjYzMzMxwcHBYWFv///wAAACH5BAEAAAYALAAAAAAQABAAAAMgaLrc/jBKFsBcg9g7iuaFZwlhaZrD1Ikqq35Xdc10PScAOw==",
                        "includes":[
                            "CSS",
                            "Style"
                        ]
                    }
                },
                "_COMMENT11_":"Should have one each for mobile, desktop, sketchhifi, sketchlofi",
                "_COMMENT12_":"For each preset, collections is list of each widget collection in order of precedence",
                "_COMMENT13_":"and sections is the array of sections for this preset (or $desktopSections)",
                "presets":{
                    "mobile":{
                        "collections":[
                            { "id":"dojoxmobile", "show":true },
                            { "id":"dijit", "show":false },
                            { "id":"html", "show":true },
                            { "id":"clipart", "show":true },
                            { "id":"shapes", "show":true }
                        ],
                        "sections":"$mobileSections"
                    },
                    "desktop":{
                        "collections":[
                            { "id":"dijit", "show":true },
                            { "id":"dojoxmobile", "show":false },
                            { "id":"html", "show":true },
                            { "id":"clipart", "show":true },
                            { "id":"xblox", "show":true },
                            { "id":"shapes", "show":true },
                            { "id":"delite", "show":true }
                        ],
                        "sections":"$desktopSections"
                    },
                    "delite":{
                        "collections":[
                            { "id":"dijit", "show":false},
                            { "id":"dojoxmobile", "show":false },
                            { "id":"html", "show":true },
                            { "id":"xblox", "show":true },
                            { "id":"delite", "show":true },
                            { "id":"shapes", "show":true },
                            { "id":"clipart", "show":true }
                        ],
                        "sections":"$deliteSections"
                    },
                    "sketchhifi":{
                        "collections":[
                            { "id":"shapes", "show":true },
                            { "id":"clipart", "show":false },
                            { "id":"dijit", "show":true },
                            { "id":"dojoxmobile", "show":true },
                            { "id":"html", "show":true }
                        ],
                        "sections":"$sketchSections",
                        "exclude":"$sketchExcludes"
                    },
                    "sketchlofi":{
                        "collections":[
                            { "id":"shapes", "show":true },
                            { "id":"clipart", "show":false },
                            { "id":"dijit", "show":true },
                            { "id":"dojoxmobile", "show":false },
                            { "id":"html", "show":true }
                        ],
                        "sections":"$sketchSections",
                        "exclude":"$sketchExcludes"
                    },
                    "$ALLMOBILE":{
                        "_COMMENT1_":"$ALLMOBILE is a special preset which shows all widgets",
                        "_COMMENT2_":"regardless of the current composition type",
                        "_COMMENT3_":"ranking mobile widgets above desktop widgets",
                        "collections":[
                            { "id":"dojoxmobile", "show":true },
                            { "id":"dijit", "show":true },
                            { "id":"html", "show":true },
                            { "id":"clipart", "show":true },
                            { "id":"xblox", "show":true },
                            { "id":"shapes", "show":true }
                        ],
                        "sections":"$ALLMOBILE_Sections"
                    },
                    "$ALLDESKTOP":{
                        "_COMMENT1_":"$ALLDESKTOP is a special preset which shows all widgets",
                        "_COMMENT2_":"regardless of the current composition type",
                        "_COMMENT3_":"ranking desktop widgets above mobile widgets",
                        "collections":[
                            { "id":"dijit", "show":true },
                            { "id":"dojoxmobile", "show":true },
                            { "id":"html", "show":true },
                            { "id":"clipart", "show":true },
                            { "id":"xblox", "show":true },
                            { "id":"shapes", "show":true }
                        ],
                        "sections":"$ALLDESKTOP_Sections"
                    },
                    "$ALLDELITE":{
                        "_COMMENT1_":"$ALLDESKTOP is a special preset which shows all widgets",
                        "_COMMENT2_":"regardless of the current composition type",
                        "_COMMENT3_":"ranking desktop widgets above mobile widgets",
                        "collections":[
                            { "id":"dijit", "show":false },
                            { "id":"dojoxmobile", "show":false},
                            { "id":"html", "show":true },
                            { "id":"clipart", "show":true},
                            { "id":"xblox", "show":true },
                            { "id":"shapes", "show":true },
                            { "id":"delite", "show":true }
                        ],
                        "sections":"$ALLDELITE_Sections"
                    }
                }
            }

        }
		return this._initializationInfo[name];
	},

	getDefaultThemeSet: function() {
		return this.getSiteConfigData("defaultThemeSet");
	},
	
	/*
	 * Based on the information available, provides an appropriate string to
	 * display that identifies the user. 
	 * 
	 * userInfo should be of the form:
	 * 
	 * 		{
	 * 			email: "person@place.com",
	 *			isLocalInstall: "false",
	 * 			userDisplayName: "",
	 *			userId: "A";
	 * 		}
	 * 
	 * Because of the current user sign-up we have with Orion, we're not making 
	 * any attempt to honor userId. In the future, it would be nice if the server
	 * could signal us if userId is appropriate.
	 * 
	 * If userInfo is undefined, then the function will look up the info for the
	 * current user.
	 * 
	 */
	getUserDisplayName: function(userInfo) {
		if (!userInfo) {
			userInfo = this.getUser();
		}

		// Can't reliably use userId anymore (because of Orion), so first try first name and then
		// drop back to e-mail
		var displayName = userInfo.userDisplayName;
		if (!userInfo.userDisplayName) {
			displayName = userInfo.email;
		}
		return displayName;		
	},

	getUserEmail: function(userInfo) {
		if (!userInfo) {
			userInfo = this.getUser();
		}
		return userInfo.email;
	},

	/*
	 * The goal is to return a string of the form:
	 * 
	 * 		displayName <email>
	 * 
	 * such as
	 * 
	 * 		Joe <joesmith@place.com>
	 * 
	 * but if displayName = email, then email will be returned.
	 * 
	 */
	getUserDisplayNamePlusEmail: function(userInfo) {
		if (!userInfo) {
			userInfo = this.getUser();
		}
		var result = this.getUserDisplayName(userInfo);
		if (result != userInfo.email) {
			result += " &lt;" + userInfo.email + "&gt;";
		}
		return result;
	},
	
	loadPlugins: function() {
        plugins.forEach(function(plugin) {
			var pluginID = plugin.id;
			Runtime.plugins[pluginID] = plugin;
			for (var id in plugin) {
				var extension = plugin[id];
				if (typeof extension != "string") {
					if (extension instanceof Array) {
						extension.forEach(function(ext) {
							Runtime._addExtension(id, ext, pluginID);
						});
					} else {
						Runtime._addExtension(id, extension, pluginID);
					}
				}
			}
		});
	},

	singleUserMode: function() {
		return Runtime.isLocalInstall;
	},

	/*
	 * @maqHack
	 * If in single user mode, returns the current active project.
	 * 
	 */
	_stripMaqetta:true,
	location: function(){
        /***
         * maqHack, remove entry file names!
         * @type {*}
         */
		var res = document.location.href.split("?")[0];
        res = res.replace('index.php','');
        res = res.replace('maqetta.html','');
        res = res.replace('xui.php','');
        res = res.replace('xui.php?debug=true','');
        res = res.replace('maqettar.html','');
        res = res.replace('index.html','');
        res = res.replace('?','');
        res = res.replace('debug=true','');
        res = res.replace('&isDesktop=true','');
        if(this._stripMaqetta){
            res=res.replace('maqetta/','');
        }
        return res;
	},

	getUserWorkspaceUrl: function(){
        //"http://localhost/projects/x4mm/Code/client/src/lib/"
        if(this.userBaseUrl){
            return this.userBaseUrl;
        }
	},

	run: function() {
		// add class to root HTML element to indicate if mac or windows
		// this is because of different alignment on mac/chrome vs win/chrome
		// FIXME: this platform-dependent logic might not be necessary if
		// main toolbar changes or different CSS applies to that toolbar
		if (dojo.isMac) {
			dojo.addClass(document.documentElement,"isMac");
		}
		
	    // determine if the browser supports CSS3 transitions
	    var thisStyle = document.body.style;
	    Runtime.supportsCSS3Transitions = thisStyle.WebkitTransition !== undefined ||
	        thisStyle.MozTransition !== undefined ||
	        thisStyle.OTransition !== undefined ||
	        thisStyle.transition !== undefined;
		
		Runtime.subscribe("/davinci/ui/selectionChanged",Runtime._selectionChanged);
		
		// intercept BS key - prompt user before navigating backwards
		dojo.connect(dojo.doc.documentElement, "onkeypress", function(e){
			if(e.charOrCode==8){
				window.davinciBackspaceKeyTime = Date.now();
			}
		});	
		//UserActivityMonitor.setUpInActivityMonitor(dojo.doc, this);

		// add key press listener
		dojo.connect(dojo.doc.documentElement, "onkeydown", this, "_handleGlobalDocumentKeyEvent");
				
		dojo.addOnUnload(function (e) {
			//This will hold a warning message (if any) that we'll want to display to the
			//user.
			var message = null;
			
			//Loop through all of the editor containers and give them a chance to tell us
			//the user should be warned before leaving the page.
			var editorContainers = (davinci.Workbench && davinci.Workbench.editorTabs) ? 
					davinci.Workbench.editorTabs.getChildren() : [];
			var editorsWithWarningsCount = 0;
			for (var i = 0; i < editorContainers.length; i++) {
				var editorContainer = editorContainers[i];
				if (editorContainer.editor) {
					var editorResponse = editorContainer.editor.getOnUnloadWarningMessage();

					if (editorResponse) {
						//Let's keep track of the first message. If we end up finding multiple messages, we'll
						//augment what the user will see shortly.
						if (!message) {
							message = editorResponse;
						}
						editorsWithWarningsCount++;
					}
				}
			}
			//If multiple warnings, augment message user will see
			if (editorsWithWarningsCount > 1) {
				message = dojo.string.substitute(webContent.multipleFilesUnsaved, [message, editorsWithWarningsCount]);
			}
			
			if (!message) {
				//No warnings so far, let's see if use maybe accidentally hit backspace
				var shouldDisplayForBackspace = Date.now() - window.davinciBackspaceKeyTime < 100;
				if (shouldDisplayForBackspace) {
					message = webContent.careful;
				}
			}
			
			if (message) {
				// We've found warnings, so we want to warn the user they run the risk of 
				// losing data if they leave the page.
				
				// For Mozilla/IE, we need to see the return value directly on the 
				// event. But, note in FF 4 and later that the browser ignores our
				// message and uses a default message of its own.
				if (e = e || window.event) {
					e.returnValue = message;
				}
				
				// For other browsers (like Chrome), the message returned by the
				// handler is honored.
				return message;
			}
		});
	},
	
	subscribe: function(topic,func) {
		Runtime.subscriptions.push(dojo.subscribe(topic,this,func));
	},
	
	destroy: function() {
		dojo.forEach(Runtime.subscriptions, dojo.unsubscribe);
	},
	
	_addExtension: function(id, extension, pluginID) {
		if (extension.id) {
			extension.id = pluginID + "." + extension.id;
		}

		Runtime.extensionPoints[id] = Runtime.extensionPoints[id] || [];
		var extensions = Runtime.extensionPoints[id];
		extensions.push(extension);
		Runtime.extensionPoints[id] = extensions;
	},
	
	getExtensions: function(extensionID, testFunction) {

		var extensions = Runtime.extensionPoints[extensionID];
		if (testFunction) {
			var matching=[];
			var isFunction = testFunction instanceof Function;
			if (extensions) {
				return extensions.filter(function(ext) {
					return (isFunction && testFunction(ext)) || ext.id == testFunction;
				});
			}
		}
		return extensions;
	},
	
	getExtension: function(extensionID, testFunction) {
		return Runtime.getExtensions(extensionID, testFunction)[0];
	},

	handleError: function(error) {
		var redirectUrl = "welcome";
		if(Runtime.singleUserMode()){
			redirectUrl = ".";
		}
		
		window.document.body.innerHTML = dojo.string.substitute(webContent.serverConnectError, {redirectUrl:redirectUrl, error: error});
	},

	executeCommand: function(cmdID) {
		var cmd=Runtime.getExtension("davinci.commands", cmdID);
		if (cmd && cmd.run) {
			cmd.run();
		}
	},
	
	_selectionChanged: function(selection) {
		Runtime.currentSelection=selection;
	},
	
	getSelection: function() {
		return Runtime.currentSelection;
	},

	// deprecated.  will fail for async.  use dojo/_base/xhr directly
	serverJSONRequest: function (ioArgs) {
		var resultObj;
		var args = {handleAs: "json"};
		dojo.mixin(args, ioArgs);

		dojo.xhrGet(args).then(function(result) {
			if (result) {
				resultObj=result;
			}
		});

		return resultObj;
	},

	registerKeyBinding: function(keyBinding, pluginAction) {
		if (!this._globalKeyBindings) {
			this._globalKeyBindings = [];
		}

		this._globalKeyBindings.push({keyBinding: keyBinding, action: pluginAction});
	},

	/* called by any widgets that pass in events from other documents, so iframes from editors */
	handleKeyEvent: function(e) {
		this._handleKeyEvent(e, true);
	},

	/* called when events are trigged on the main document */
	_handleGlobalDocumentKeyEvent: function(e) {
		this._handleKeyEvent(e);
	},

	_handleKeyEvent: function(e, isFromSubDocument) {

		if (!this._globalKeyBindings) {
			return;
		}

		var stopEvent = false;

		stopEvent = dojo.some(this._globalKeyBindings, dojo.hitch(this, function(globalBinding) {
			if (Runtime.isKeyEqualToEvent(globalBinding.keyBinding, e)) {
				davinci.Workbench._runAction(globalBinding.action);
				return true;
			}
		}));

		if (stopEvent) {
			dojo.stopEvent(e);
		} else if (!isFromSubDocument) {
			// if not from sub document, let the active editor take a stab
			if (this.currentEditor && this.currentEditor.handleKeyEvent) {
				// pass in true to tell it its a global event
				this.currentEditor.handleKeyEvent(e, true);
			}
		}
	},

	// compares keybinding to event
	isKeyEqualToEvent: function(keybinding, e) {
		var equal = true;

		var hasAccel = ((e.ctrlKey && !dojo.isMac) || (dojo.isMac && e.metaKey))
		var hasMeta = ((e.altKey && !dojo.isMac) || (dojo.isMac && e.ctrlKey))


		if (!!keybinding.accel !== hasAccel) {
			equal = false;
		}

		if (!!keybinding.meta !== hasMeta) {
			equal = false;
		}

		if (!!keybinding.shift !== e.shiftKey) {
			equal = false;
		}

		if (equal && keybinding.charOrCode && e.which) {
			if (dojo.isArray(keybinding.charOrCode)) {
				equal = dojo.some(keybinding.charOrCode, dojo.hitch(this, function(charOrCode) {
					return this._comparecharOrCode(charOrCode, e);
				}));
			} else {
				equal = this._comparecharOrCode(keybinding.charOrCode, e);
			}
		}

		return equal;
	},

	_comparecharOrCode: function(charOrCode, e) {
		var equal;

		if (dojo.isString(charOrCode)) {
			// if we have a string, use fromCharCode
			equal = (charOrCode.toLowerCase() === String.fromCharCode(e.which).toLowerCase());
		} else {
			equal = (charOrCode === e.which);
		}

		return equal;
	}
};

return Runtime;
});
