define({ root:
{
		//ui/FormatOptions.js
		"newLineForBlocks":"New line for blocks",
		"blockIndention":"Block indentation",
		"newLineForFuncBodies":"New line for function bodies",
		"functionIndention":"Function indentation",
		"funcParameterListSpacing":"Function parameter list spacing",
		"labelSpacing":"Label spacing",
		"newLineAfterLabel":"New line after label",
		"forStatementSpacing":"'for' statement parameter spacing",
		"ifStatementSpacing":"'if' statement spacing",
		"varAssignmentSpacing":"'var' assignment spacing",
		"switchSpacing":"'switch' spacing",
		"objectLiteralFieldSpacing":"Object literal field spacing"
		

}
});
