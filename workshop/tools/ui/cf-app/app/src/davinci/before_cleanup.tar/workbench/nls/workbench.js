define({ root:
{
		//EditorContainer.js
		"fileHasUnsavedChanges":"The file '${0}' has unsaved changes. Are you sure you want to close WITHOUT saving?",
		
		//OutlineView.js
		"outlineNotAvailable":"An outline is not available",
		
		//Preferences.js
		"preferences":"Preferences",
		"noUserPref":"no user preferences...",
		"restoreDefaults":"Restore Defaults"
}
});
