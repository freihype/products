define([
	"dojo/_base/declare"
], function(declare) {
	return declare(null, {});
});
