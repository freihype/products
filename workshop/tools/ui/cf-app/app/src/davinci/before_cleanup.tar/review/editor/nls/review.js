define({ root:
{
	//ReviewEditor.js
	"unsavedComment": "The file '${0}' has an unsaved comment in the Comments tab. Are you sure you want to close WITHOUT saving?"
}
});