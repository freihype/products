define({ root:
{
		//CommentExplorerView.js
		"closeVersion":"Stop Review...",
		"openVersion":"Start Review",
		"editVersion":"Edit Review...",
		"filter":"Type to filter...",
		"designer": "Designer",
		"reviewer": "Reviewer",
		"infinite": "Infinite",
		
		//CommentView.js
		"allReviewers":"All Reviewers",
		"addComment": "Add comment",
		"showReviewer":"Show review participants"
}
});