/** @module davinci/ve/PageEditor **/
define([
    "require",
    "dojo/_base/declare",
    "../ui/ModelEditor",
    "dojo/dnd/Moveable",
    "../Runtime",
    "../commands/CommandStack",
    "../html/ui/HTMLEditor",
    "./VisualEditor",
    "./VisualEditorOutline",
    "./widget",
    "./States",
    "../XPathUtils",
    "../html/HtmlFileXPathAdapter",
    "./utils/GeomUtils",
    "davinci/model/Factory",
    'xide/mixins/EventedMixin',
    'xide/mixins/ReloadMixin',
    'xide/utils',
    'xide/types',
    'xide/factory',
    'xideve/views/BlocksFileEditor',
    'xide/widgets/_Widget',
    'xide/views/_LayoutMixin',
    'xdocker/Docker2',
    'xdocker/types',
    'wcDocker/iframe'

], function (require, declare, ModelEditor,
             Moveable, Runtime, CommandStack, HTMLEditor,
             VisualEditor, VisualEditorOutline,
             widgetUtils, States, XPathUtils, HtmlFileXPathAdapter,
             GeomUtils, Factory, EventedMixin,
             ReloadMixin,
             utils,types,factory, BlocksFileEditor,_Widget,_LayoutMixin,Docker,iframe)
{


    var debugBlocks = false;
    /**
     * @class module:davinci/ve/PageEditor
     */
    var Module=declare("davinci.ve.PageEditor", [ModelEditor,_Widget,EventedMixin, ReloadMixin,_LayoutMixin], {
        _latestSourceMode: "source",
        _latestLayoutMode: "flow",
        item: null,
        delegate: null,
        template: null,
        bottomTabContainer: null,
        textEditorPane: null,
        didBlockViews: false,
        _propCP:null,
        createTab:function(type,args){
            var DOCKER = types.DOCKER;
            var defaultTabArgs = {
                icon:false,
                closeable:true,
                moveable:true,
                tabOrientation:DOCKER.TAB.TOP,
                location:DOCKER.DOCK.STACKED

            };
            return this._docker.addTab(type || 'DefaultTab',utils.mixin(defaultTabArgs,args));
        },
        createLayout:function(){},
        constructor: function (element, fileName, fileItem, editorCreationFn, template, additionalEditors) {
            var DOCKER = types.DOCKER;
            var bottomTarget = null;
            this.item = fileItem;
            this.template = template;
            var thiz = this;
            this._commandStack = new CommandStack(this);
            this.savePoint = 0;
            this._docker = Docker.createDefault(element,{
            });

            this.domNode = this._docker.$container[0];

            /*
            this._designCP = this.createTab(null,{
                title:'Design',
                //title:false,
                icon:'fa-eye'
            });
            */
            this._designCP = this.createTab(null,{
                title:'Design',
                //title:false,
                icon:'fa-eye'
            });




            function unlock(delay){
                setTimeout(function(){
                    var context = thiz.getContext();
                    context && context.frameNode && $(context.frameNode).css('pointer-events','initial');
                },delay || 4000);
            }
            this._docker.on(types.DOCKER.EVENT.BEGIN_RESIZE,function(e){
                var context = thiz.getContext();
                context &&  context.frameNode && $(context.frameNode).css('pointer-events','none');
                unlock();
            });

            this._docker.on(types.DOCKER.EVENT.MOVE_STARTED,function(e){
                var context = thiz.getContext();
                context &&  context.frameNode && $(context.frameNode).css('pointer-events','none');
                unlock();
            });

            this._docker.on(types.DOCKER.EVENT.MOVE_ENDED,function(e){
                unlock(1);
            });

            this._docker.on(types.DOCKER.EVENT.END_RESIZE,function(e){
                unlock(1);
            });

            this._docker.on(types.DOCKER.EVENT.BEGIN_FLOAT_RESIZE,function(e){
                var context = thiz.getContext();
                $(context.frameNode).css('pointer-events','none');
                unlock();
            });

            this._docker.on(types.DOCKER.EVENT.END_FLOAT_RESIZE,function(e){
                unlock(1);
            });

            this._designCP.$container[0].domNode = this._designCP.$container[0];

            this._designCP.domNode =this._designCP.$container[0];
            this._designCP.minSize(400,400);
            
            this.visualEditor = new VisualEditor(this._designCP.$container[0], this, this.template);
            this.currentEditor = this.visualEditor;
            this.currentEditor._commandStack = this._commandStack;
            this.initReload();
            try {
                var editors = additionalEditors;
                this._propCP = this.createTab(null,{
                    title:'Props',
                    icon:'fa-cogs',
                    tabOrientation: DOCKER.TAB.TOP,
                    location: DOCKER.TAB.RIGHT,
                    target:this._designCP
                });
                this._propCP.maxSize(400);
                this._propCP.minSize(350);
                this._propCP.closeable(false);

                var textEditorParent = null;
                var editorPane = null;

                if (editors.length) {
                    editorPane = this.createTab(null,{
                        title:'HTML',
                        icon:'fa-code',
                        tabOrientation: DOCKER.TAB.TOP,
                        location: DOCKER.TAB.BOTTOM
                    });
                    textEditorParent = editorPane.domNode;
                    this._srcCP = editorPane;
                }else{
                    console.error('have no editors, ');
                }

                var useAce = true;
                var htmlEditor = null;
                try {
                    if (!useAce) {
                        htmlEditor = this.htmlEditor = new HTMLEditor(textEditorParent, fileName, true);
                    } else {
                        htmlEditor = this.htmlEditor = editorCreationFn(editorPane);
                    }
                } catch (e) {
                    debugger;
                }


                this.model = htmlEditor.model;

                htmlEditor._on(types.EVENTS.ON_FILE_CONTENT_CHANGED,function(evt){
                    thiz.delegate.onEditorContentChanged(evt);
                });


                this._displayMode = "design";
                this._connect(this.visualEditor, "onContentChange", "_visualChanged");
                this.subscribe("/davinci/ui/styleValuesChange", this._stylePropertiesChange);
                this.subscribe("/davinci/ui/widgetSelected", this._widgetSelectionChange);
                this.subscribe("/davinci/ui/selectionChanged", this._modelSelectionChange);
                //this._connect(this.visualEditor.context, "onSelectionChange","_widgetSelectionChange");
                this.subscribe("/davinci/ui/editorSelected", this._editorSelected.bind(this));
                this.subscribe("/davinci/ui/context/loaded", this._contextLoaded.bind(this));
                this.subscribe("/davinci/ui/deviceChanged", this._deviceChanged.bind(this));
                this._designCP.getSplitter().pos(0.5);
                setTimeout(function(){
                    thiz._srcCP.getSplitter().pos(0.5);
                    thiz._propCP.maxSize(500);
                },1500);
                this.resize();

            } catch (e) {
                this.visualEditor._connectCallback(e);
                console.error('page editor crash : ' + e);
            }
            this.add(this._docker);
        },
        getPropertyPane:function(){
            return this._propCP;
        },
        getDesignPane:function(){
            return this._designCP;
        },
        getSourcePane:function(){
            return this._srcCP;
        },
        /**
         * Return Davinci's Visual Editor
         * @returns {module:davinci/ve/VisualEditor}
         */
        getVisualEditor:function(){
            return this.visualEditor;
        },
        getBlocksPane:function(){
            return this._blocksTab;
        },
        /**
         *
         * @param evt
         */
        onSceneBlocksLoaded: function (evt,ve) {
            if(ve.showBlocks==false){
                return;
            }
            if (this.didBlockViews) {
                return;
            }
            this.didBlockViews = true;

            var scopes = evt.blockScopes;
            var ctx = evt.ctx;
            var tabContainer = this.bottomTabContainer,
                thiz = this;
            var DOCKER = types.DOCKER;
            this._blocksTab = this.createTab(null,{
                title:'Blocks',
                icon:'fa-eye',
                target:this._srcCP,
                tabOrientation:DOCKER.TAB.TOP,
                location:DOCKER.DOCK.STACKED
            });

            var _createBlockEditor = function (scope, where) {
                var blockEditor = utils.addWidget(BlocksFileEditor, {
                    style: 'height:inherit;width:inherit;padding:0px;',
                    ctx: ctx,
                    pageEditor:thiz,
                    visualEditor:ve,
                    editorContext:thiz.getContext(),
                    item: {
                        path: scope.path,
                        mount: scope.mount
                    }
                }, thiz, where, true);

                blockEditor.initWithScope(scope);
                where.add(blockEditor);
                return blockEditor;
            };

            var scope = scopes[0];
            this._blockEditor = _createBlockEditor(scope, this._blocksTab);
            var selectedItem = ve.getItem();
            if(selectedItem){
                this._blockEditor._widgetSelectionChanged({
                    selection:[selectedItem]
                });
            }
            return;
        },
        getBlockEditor:function(){
            return this._blockEditor;
        },
        setRootElement: function (rootElement) {
            this._rootElement = rootElement;
        },
        supports: function (something) {
            // Note: the propsect_* values need to match the keys in SwitchingStyleView.js
            var regex = /^palette|properties|style|states|inline-style|MultiPropTarget|propsect_common|propsect_widgetSpecific|propsect_events|propsect_layout|propsect_paddingMargins|propsect_background|propsect_border|propsect_fontsAndText|propsect_shapesSVG$/;
            return something.match(regex);
        },
        focus: function () {
//		if(this.currentEditor==this.visualEditor)
//			this.visualEditor.onContentChange();
        },
        _editorSelected: function (event) {
            var context = this.getContext();
            if (!context) {
                return;
            }
            if (this == event.oldEditor) {
                context.hideFocusAll();
            }
            if (event.editor && event.editor.editorContainer &&
                (event.editor.declaredClass == 'davinci.ve.PageEditor' ||
                event.editor.declaredClass == 'davinci.ve.themeEditor.ThemeEditor')) {
                if (this == event.editor) {
                    var flowLayout = context.getFlowLayout();
                    var layout = flowLayout ? 'flow' : 'absolute';
                    this._updateLayoutDropDownButton(layout);
                    context.clearCachedWidgetBounds();
                }
            }
        },
        _contextLoaded: function () {
            try {
                if (Runtime && Runtime['currentEditor']) {
                    if (Runtime.currentEditor == this && this.editorContainer) {
                        // this.editorContainer.updateToolbars();
                    }
                } else {
                    //console.error('#hack : ' + 'Runtime.currentEditor');
                }
            } catch (e) {
                console.error('_contextLoaded:crash' + e.message);
            }
        },
        _deviceChanged: function () {
            if (Runtime.currentEditor == this && this.editorContainer) {
                var context = this.getContext();
                if (context && context.updateFocusAll) {
                    // setTimeout is fine to use for updateFocusAll
                    // Need to insert a delay because new geometry
                    // isn't ready right away.
                    // FIXME: Should figure out how to use deferreds or whatever
                    // to know for sure that everything is all set and we
                    // can successfully redraw focus chrome
                    setTimeout(function () {
                        context.updateFocusAll();
                    }, 1000);
                }
            }
        },
        _updateLayoutDropDownButton: function (newLayout) {
            var layoutDropDownButtonNode = dojo.query('.maqLayoutDropDownButton');
            if (layoutDropDownButtonNode && layoutDropDownButtonNode[0]) {
                var layoutDropDownButton = dijit.byNode(layoutDropDownButtonNode[0]);
                if (layoutDropDownButton) {
                    //layoutDropDownButton.set('label', veNls['LayoutDropDownButton-'+newLayout]);
                }
            }

        },
        _selectLayout: function (layout) {
            this._latestLayoutMode = layout;
            require(["davinci/actions/SelectLayoutAction"], function (SelectLayoutAction) {
                var SelectLayoutAction = new SelectLayoutAction();
                SelectLayoutAction._changeLayoutCommand(layout);
            });
            this._updateLayoutDropDownButton(layout);
        },
        selectLayoutFlow: function () {
            this._selectLayout('flow');
        },
        selectLayoutAbsolute: function () {
            this._selectLayout('absolute');
        },
        getDisplayMode: function () {
            return this._displayMode;
        },
        getSourceDisplayMode: function () {
            return this._latestSourceMode;
        },
        _switchDisplayModeSource: function (newMode) {
            this._latestSourceMode = newMode;
            this.switchDisplayMode(newMode);
        },
        switchDisplayModeSource: function () {
            this._switchDisplayModeSource("source");
        },
        switchDisplayModeSplitVertical: function () {
            this._switchDisplayModeSource("splitVertical");
        },
        switchDisplayModeSplitHorizontal: function () {
            this._switchDisplayModeSource("splitHorizontal");
        },
        switchDisplayModeSourceLatest: function () {
            this.switchDisplayMode(this._latestSourceMode);
        },
        switchDisplayModeDesign: function () {
            this.switchDisplayMode("design");
        },
        switchDisplayMode: function (newMode) {

            return;
            var context = this.getContext();
            if (this._displayMode != "design") {
                this._bc.removeChild(this._srcCP);
                this.htmlEditor.setVisible(false);
            }

            // reset any settings we have used
            this._designCP.set("region", "center");
            delete this._designCP.domNode.style.width;
            delete this._srcCP.domNode.style.width;

            switch (newMode) {
                case "design":
                    break;
                case "source":
                    // we want to hide the design mode.  So we set the region to left
                    // and manually set the width to 0.
                    this._designCP.set("region", "left");
                    this._designCP.domNode.style.width = 0;
                    this._srcCP.set("region", "center");
                    break;
                case "splitVertical":
                    this._designCP.domNode.style.width = "50%";
                    this._srcCP.set("region", "right");
                    this._srcCP.domNode.style.width = "50%";
                    this._bc.set("design", "sidebar");
                    break;
                case "splitHorizontal":
                    this._designCP.domNode.style.height = "50%";

                    this._srcCP.set("region", "bottom");
                    this._srcCP.domNode.style.height = "50%";

                    this._bc.set("design", "headline");
            }

            if (newMode != "design") {
                this._bc.addChild(this._srcCP);
                this.htmlEditor.setVisible(true);
                this.hidePropertyPane(true);

            }

            this._displayMode = newMode;

            // now lets relayout the bordercontainer

            this.resize();

            this._bc.layout();

            if (this.editorContainer) {
                this.editorContainer.updateToolbars();
            }

            dojo.publish('/davinci/ui/repositionFocusContainer', []);

            if (newMode == "source") {
                this.hidePropertyPane(true);
                context.hideFocusAll();
            } else {
                this.hidePropertyPane(false);
                context.clearCachedWidgetBounds();
                context.updateFocusAll();
            }


        },
        hidePropertyPane:function(hide){
            var pane = this.getPropertyPane();
            //pane && hide==true && pane._close ? pane._close() : pane._open();
        },
        _modelSelectionChange: function (selection) {
            /*
             * we do not want to drive selection on the view editor unless:
             *     - we are in an editor mode which has a view editor (not source mode)
             *     - we are the current editor
             */
            if (this._displayMode == "source" || require("davinci/Runtime").currentEditor !== this) { //FIXME: require("davinci/Runtime")!=Runtime.  Why??
                return;
            }

            this._selectionCssRules = null;
            if (selection.length) {
                var htmlElement = selection[0].model;
                if (htmlElement && htmlElement.elementType == "HTMLElement") {
                    var id = htmlElement.getAttribute("id");
                    if (id && this._displayMode != "source") {
                        var widget = widgetUtils.byId(id, this.visualEditor.context.getDocument());
                        var box = GeomUtils.getMarginBoxPageCoords(widget.domNode);
                        this.getContext().getGlobal().scroll(box.l, box.t);
                        this.visualEditor.context.select(widget);
                    }
                }
            }
        },
        _widgetSelectionChange: function (selection) {
            if(selection.isFake===true){
                return;
            }
            if (!this.visualEditor.context ||
                (selection && selection.length && selection[0]._edit_context != this.visualEditor.context)) {
                return;
            }
            var selection = this.visualEditor.context.getSelection();
            if (selection && selection.length) {
                if (this._displayMode != "design") {
                    this.htmlEditor.selectModel([{model: selection[0]._srcElement}]);
                }
            }
        },
        _stylePropertiesChange: function (value) {

            console.log('_stylePropertiesChange',value);
            if(value && value.cascade && value.cascade._widget && value.cascade._widget.isFake==true){
                return;
            }
            this.visualEditor._stylePropertiesChange(value);
            var selection = this.visualEditor.context.getSelection();
            //console.log('_stylePropertiesChange ',selection);
            if(selection && selection[0]){
                var node =utils.getNode(selection[0]);
                if(node && node.onChanged){
                    node.onChanged();
                }
            }
            var widget = value.cascade._topWidgetDom;
            var style = $(widget).attr("style");
            this.getContext().updateBackground(widget);
            /*

            if(value.values[0]){
                var _value = value.values[0];
                if(_value) {
                    var url = _value['background-image'];
                    if(url) {
                        console.log('back ground image: ' + _value['background-image']);
                        url = utils.getBackgroundUrl(style);
                        //url = url.replace('url(', '').replace(')', '');
                        //url = utils.replaceAll('\'','',url);
                        if (widget) {
                            var $widget = $(widget);
                            var parts = utils.parse_url(url);
                            url = this.ctx.getFileManager().getImageUrl({
                                path:parts.host + parts.path,
                                mount:parts.scheme
                            },true);
                            console.log('url ' + url);
                            $widget.css('background-image',"url('" + url + "')");

                        }
                    }
                }
            }
            */
        },
        _setDirty: function () {
            this.setDirty(true);
        },
        setDirty: function (isDirty) {
            this.isDirty = isDirty;
            if (isDirty) {
                this.lastModifiedTime = Date.now();
            }
            if (this.editorContainer) {
                this.editorContainer.setDirty(isDirty);
            }
        },
        _visualChanged: function (skipDirty) {
            if (!this.delegate.shouldUpdateTextEditor()) {
                return;
            }
            if (!skipDirty) {
                this._setDirty();
            }
            this.htmlEditor.set('value',this.model.getText(), true);
            
            //console.log('visual changed');
            this.getContext().visualEditorChanged();
        },
        _srcChanged: function () {
            // Because this can be called from SourceChangeCommand, make sure dojo.doc is bound to the Workbench
            dojo.withDoc(window.document, function () {
                var wasTyping = this.htmlEditor.isTyping;
                if (wasTyping) {
                    this.visualEditor.skipSave = true;
                }
                var context = this.visualEditor.context,
                    statesScenes = context && this._getStatesScenes(context);
                this.visualEditor.setContent(this.fileName, this.htmlEditor.model);
                this.editorContainer.updateToolbars();
                dojo.publish('/davinci/ui/context/pagerebuilt', [context]);
                if (statesScenes) {
                    this._setStatesScenes(context, statesScenes);
                }
                delete this.visualEditor.skipSave;
                this._setDirty();
            }, this);
        },
        /**
         * Returns an object holding the set of currently selected application states and (mobile) scenes
         * @return {object}  { statesInfo:statesInfo, scenesInfo:scenesInfo }
         */
        _getStatesScenes: function (context) {
            return [];
            var statesFocus = States.getFocus(context.rootNode);
            if (!statesFocus) {
                statesFocus = {stateContainerNode: context.rootNode};
            }
            if (typeof statesFocus.state != 'string') {
                statesFocus.state = States.NORMAL;
            }
            var statesInfo = States.getAllStateContainers(context.rootNode).map(function (stateContainer) {
                var currentState = States.getState(stateContainer);
                var currentStateString = typeof currentState == 'string' ? currentState : States.NORMAL;
                var xpath = XPathUtils.getXPath(
                    stateContainer._dvWidget._srcElement,
                    HtmlFileXPathAdapter);
                var focus = statesFocus.stateContainerNode == stateContainer &&
                    statesFocus.state == currentStateString;
                return {currentStateXPath: xpath, state: currentState, focus: focus};
            });
            scenesInfo = {};
            var sceneManagers = context.sceneManagers;
            for (var smIndex in sceneManagers) {
                var sm = sceneManagers[smIndex];
                scenesInfo[smIndex] = {sm: sm};
                scenesInfo[smIndex].sceneContainers = sm.getAllSceneContainers().map(function (sceneContainer) {
                    var currentScene = sm.getCurrentScene(sceneContainer);
                    var sceneContainerXPath = XPathUtils.getXPath(
                        sceneContainer._dvWidget._srcElement,
                        HtmlFileXPathAdapter);
                    var currentSceneXPath = XPathUtils.getXPath(
                        currentScene._dvWidget._srcElement,
                        HtmlFileXPathAdapter);
                    return {
                        sceneContainerXPath: sceneContainerXPath,
                        currentSceneXPath: currentSceneXPath
                    };
                });
            }
            return {statesInfo: statesInfo, scenesInfo: scenesInfo};
        },
        /**
         * Sets the current scene(s) and/or current application state
         * @param {object}  object of form { statesInfo:statesInfo, scenesInfo:scenesInfo }
         */
        _setStatesScenes: function (context, statesScenes) {
            //#xmaqhack
            return;
            var statesInfo = statesScenes.statesInfo;
            if (statesInfo) {
                for (var i = 0; i < statesInfo.length; i++) {
                    var info = statesInfo[i],
                        xpath = info.currentStateXPath,
                        element = context.model.evaluate(xpath);
                    if (!element) {
                        continue;
                    }
                    var widget = widgetUtils.byId(element.getAttribute('id'), context.getDocument());
                    States.setState(info.state, widget.domNode, {focus: info.focus});
                }
            }

            var scenesInfo = statesScenes.scenesInfo;
            for (var smIndex in scenesInfo) {
                var sm = scenesInfo[smIndex].sm,
                    allSceneContainers = scenesInfo[smIndex].sceneContainers;
                for (i = 0; i < allSceneContainers.length; i++) {
                    var sceneContainer = allSceneContainers[i],
                        xpath = sceneContainer.sceneContainerXPath,
                        element = context.model.evaluate(xpath);
                    if (!element) {
                        continue;
                    }
                    var widget = widgetUtils.byId(element.getAttribute('id'), context.getDocument()),
                        sceneContainerNode = widget.domNode;

                    xpath = sceneContainer.currentSceneXPath;
                    element = context.model.evaluate(xpath);
                    if (!element) {
                        continue;
                    }
                    sm.selectScene({sceneContainerNode: sceneContainerNode, sceneId: element.getAttribute('id')});
                }
            }
        },
        getContext: function () {
            return this.visualEditor.context;
        },
        getOutline: function () {
            if (!this.outline) {
                this.outline = new VisualEditorOutline(this);
            }
            return this.outline;
        },
        getPropertiesView: function () {
            return this.currentEditor.getPropertiesView();
        },
        setContent: function (filename, content, newHtmlParams) {

            /*// clear the singletons in the Factory
             this.htmlEditor.htmlFile.visit({visit:function(node) {
             if (node.elementType == "CSSImport") {
             node.close();
             }
             }});*/
            this.fileName = filename;
            this.htmlEditor.setContent(filename, content);
            this.visualEditor.setContent(filename, this.htmlEditor.model, newHtmlParams);
            this._connect(this.htmlEditor.model, "onChange", "_themeChange");
            // update the source with changes which may have been made during initialization without setting dirty bit
            //this.htmlEditor.setValue(this.model.getText(), true);
        },
        _themeChange: function (e) {
            if (e && e.elementType === 'CSSRule') {
                this.setDirty(true); // a rule change so the CSS files are dirty. we need to save on exit
                this.visualEditor.context.hotModifyCssRule(e);
            }
        },
        getDefaultContent: function () {
            this._isNewFile = true;
            return this.visualEditor.getDefaultContent();
        },
        selectModel: function (selection, editor) {
            if (this.publishingSelect || (editor && this != editor)) {
                return;
            }
            var selectionItem = selection && selection[0];
            if (!selectionItem) {
                return;
            }
            if (selectionItem.elementType) {
                this.htmlEditor.selectModel(selection);
            } else if (selectionItem.model && selectionItem.model.isWidget) {
                this.visualEditor.context.select(selectionItem.model, selectionItem.add);
            }
        },
        save: function (isAutoSave) {


            if (this.delegate && this.delegate.save) {

                var model = this.visualEditor.context.getModel();
                var modelText = model.getText();
                this.delegate.save(this, this.visualEditor, model, modelText);
                return;
            }

            //	this.inherited(arguments);


            if (isAutoSave) {

                /*if (system.resource.findResource(this.fileName).readOnly()) {
                 // disable autosaving for readonly files
                 return;
                 }
                 */
            }
            this.savePoint = this._commandStack.getUndoCount();
            var promises = this.visualEditor.save(isAutoSave);
            if (promises && promises.then) {
                promises.then(
                    function (results) {
                        this.isDirty = isAutoSave;
                        if (this.editorContainer && this.editorContainer.domNode) {
                            this.editorContainer.setDirty(isAutoSave);
                        }
                    }.bind(this),
                    function (error) {
                        /*var message = veNls.vteErrorSavingResourceMessage + error;
                         dojo.publish("/davinci/resource/saveError", [{message:message, type:"error"}]);
                         console.error(message);
                         */
                    }
                );
            }


        },
        removeWorkingCopy: function () { //wdr
            //this.visualEditor.removeWorkingCopy();
        },
        previewInBrowser: function () {
            this.visualEditor.previewInBrowser();
        },
        destroy: function () {
            this.inherited(arguments);
            this.visualEditor.destroy();
            this.htmlEditor.destroy();
            utils.destroy(this.bottomTabContainer);
        },
        getText: function () {
            return this.htmlEditor.getText();
        },
        onResize: function () {
            var context = this.getContext();
            var selections = context.getSelection();
            for (var i = 0; i < selections.length; i++) {
                var add = (i != 0);
                context.select(selections[i], add);
            }
        },
        // dummy handler
        handleKeyEvent: function (e) {
        },
        /**
         * Return clipping bounds for focusContainer node, whose main purpose is to
         * clip the selection chrome so it doesn't impinge on other parts of the UI
         */
        getFocusContainerBounds: function () {
            if (this._displayMode == 'source') {
                return {l: 0, t: 0, w: 0, h: 0};
            } else {
                var clipTo = this._designCP.domNode;
                var box = GeomUtils.getBorderBoxPageCoords(clipTo);

                /*FIXME: See #2951. This isn't working in all cases yet, so commenting out.
                 When a silhouette is active, need to check for an active scroll bar on this._designCP.domNode
                 but when no silhouette, need to check the HTML node on the user's document within iframe.
                 Code below only deals with this._designCP.domNode.
                 // Back off selection chrome in case this._designCP has scrollbar(s)
                 if(clipTo.scrollWidth > clipTo.clientWidth && (clipTo.clientWidth - scrollbarWidth) < box.w){
                 box.w = clipTo.clientWidth - scrollbarWidth;
                 }
                 if(clipTo.scrollHeight > clipTo.clientHeight && (clipTo.clientHeight - scrollbarWidth) < box.h){
                 box.h = clipTo.clientHeight - scrollbarWidth;
                 }
                 */


                // Make the clip area 8px bigger in all directions to make room
                // for selection chrome, which is placed just outside bounds of widget
                box.l -= 8;
                box.t -= 8;
                var device = (this.visualEditor && this.visualEditor.getDevice) ? this.visualEditor.getDevice() : 'none';
                if (device == 'none') {
                    box.w += (this._displayMode == 'splitVertical' ? 8 : 16);
                    box.h += (this._displayMode == 'splitHorizontal' ? 8 : 16);
                } else {
                    box.w += 8;
                    box.h += 8;
                }
                return box;
            }
        },
        getCommandStack: function () {
            var context = this.getContext();
            return context.getCommandStack();
        }
    });

    Module.__test = "asd2f";

    return Module;
}); 
