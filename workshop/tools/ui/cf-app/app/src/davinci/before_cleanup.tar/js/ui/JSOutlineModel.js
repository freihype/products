define([
	"dojo/_base/declare",
	"davinci/ui/widgets/DavinciModelTreeModel"
], function(declare, DavinciModelTreeModel) {

return declare("davinci.js.ui.JSOutlineModel", DavinciModelTreeModel, {

});
});
