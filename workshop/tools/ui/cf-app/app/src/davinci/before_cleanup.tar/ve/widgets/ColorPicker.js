define([
    "davinci/ve/widgets/ColorPicker2",
    "dijit/popup"
], function (ColorPicker2) {
    return ColorPicker2;
});